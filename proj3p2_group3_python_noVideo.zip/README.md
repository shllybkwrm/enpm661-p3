# enpm661-p3
Project 3 for ENPM661, Spring 2020, UMD-CP
Shelly Bagchi & Omololu Makinde

To run project:
python Astar_rigid.py

Dependencies:
numpy
matplotlib

Github:  https://github.com/shllybkwrm/enpm661-p3
